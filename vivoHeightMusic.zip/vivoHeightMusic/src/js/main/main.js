define(function (require,exports,module){
	//主模块不用暴露接口，家宅时直接执行下面的代码
	var $ = require('zepto');
	$(document).ready(function (){
		//1.图片预加载显示进程
		var preload = require('main/imagePreload');
		
		//2.显示广告字体
		var indexText = require('main/indexText');
		
		//兼容某些手机无法自动播放音乐autoplay
//		var musicPlay = require('main/musicPlay');
		
		//3.预加载完毕后，执行第一屏消失动画
		
		
		
		
		//4.第一屏手机图片到达到达指定位置后，主场动画进入，开始动画
		
		
		
		
		
		
		//5.主场动画展示完毕后，出现使用提示，点击后，背景层隐藏消失,气球开始运动
		
		
		
		
		
		//6.陀螺仪转动
		
		
		
		
		
		//7.手滑屏功能处理，---同陀螺仪功能相当。
		
		
		
		
		
		
		//8.点击的相应操作---点击提示，其他音乐暂停，对应音乐播放，对应动画开始
		
		
		
		
		
		
			    
	
	
	
	})
	
    
});